#include <iostream>
#include <fstream>
#include "../System/UberSystem.h"

int main()
{
	UberSystem us;
	us.NotLoggedIn();
}
